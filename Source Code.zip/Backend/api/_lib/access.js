import { createSupabaseAdmin } from './supabase.js';
import { readBearerToken } from './http.js';

export const SUPER_ADMIN_ROLES = new Set([
  'couple_coordinator',
  'area_servant',
  'lit_servant'
]);

export function isSuperAdminRole(role) {
  return SUPER_ADMIN_ROLES.has(String(role || '').trim().toLowerCase());
}

export function isChapterServantRole(role) {
  return String(role || '').trim().toLowerCase() === 'chapter_servant';
}

export async function requireAuthenticatedProfile(req) {
  const token = readBearerToken(req);
  if (!token) {
    const error = new Error('Authentication required.');
    error.statusCode = 401;
    error.code = 'AUTH_REQUIRED';
    throw error;
  }

  const supabase = createSupabaseAdmin();
  const { data: userData, error: userError } = await supabase.auth.getUser(token);
  if (userError || !userData?.user) {
    const error = new Error('Session is invalid or expired.');
    error.statusCode = 401;
    error.code = 'INVALID_SESSION';
    throw error;
  }

  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userData.user.id)
    .maybeSingle();

  if (profileError) throw profileError;
  if (!profile || profile.is_active === false) {
    const error = new Error('This account is not active.');
    error.statusCode = 403;
    error.code = 'ACCOUNT_INACTIVE';
    throw error;
  }

  return { supabase, user: userData.user, profile, token };
}
